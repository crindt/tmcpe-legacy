({
	createLinkTitle: "Właściwości odsyłacza",
	insertImageTitle: "Właściwości obrazu",
	url: "Adres URL:",
	text: "Opis:",
	set: "Ustaw"
})
