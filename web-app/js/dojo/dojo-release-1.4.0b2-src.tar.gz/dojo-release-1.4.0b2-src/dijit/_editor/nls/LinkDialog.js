({
	createLinkTitle: "Link Properties",
	insertImageTitle: "Image Properties",
	url: "URL:",
	text: "Description:",
	target: "Target:",
	set: "Set",
	cancel: "Cancel",
	currentWindow: "Current Window ( _self )",
	parentWindow: "Parent Window ( _parent )",
	topWindow: "Topmost Window ( _top )",
	newWindow: "New Window ( _blank )"
})
